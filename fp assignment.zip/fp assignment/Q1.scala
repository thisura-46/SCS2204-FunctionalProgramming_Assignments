object Q1 extends App{
  def toFahrenheit(t: Double):Double = t*1.8 + 32

  print("Celsius 35 is equal to Fahrenheit: "+ toFahrenheit(35))
}